<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Counter Biru Celluler</title>


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/5.8.55/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">

  <!-- inject:css -->
  <link rel="stylesheet" href="assets/css/style.css">
  <!-- endinject -->

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <link rel="shortcut icon" href="assets/images/favicon.png" />
  <style>
    table.dataTable thead th,
    table.dataTable thead td {
      border-bottom: none !important;
    }

    table.dataTable.no-footer {
      border-bottom: none !important;
    }

    table.dataTable tbody th,
    table.dataTable tbody td {
      border-top: none !important;
    }

    table.dataTable {
      border-collapse: collapse;
    }

    table.dataTable td,
    table.dataTable th {
      border: none !important;
    }
  </style>
</head>

<body>


  <?php
  session_start();
  date_default_timezone_set('Asia/Jakarta');
  // Memeriksa apakah pengguna sudah login
  if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    // Memeriksa role dan memuat konten yang sesuai
    if ($_SESSION['role'] == '1') {
      include('pages/admin/home.php');
    } else {
      include('pages/manager/manager.php');
    }
  } else {
    // Jika tidak ada session, arahkan ke halaman login
    header("Location: login.php");
    exit();
  }
  ?>
  <!-- Modal -->
  <div class="modal fade" id="updateUserModal" tabindex="-1" aria-labelledby="updateUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="updateUserModalLabel">Update Pengguna</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form id="updateUserForm" method="POST" action="update_user.php">
          <div class="modal-body">
            <div class="mb-3">
              <label for="id" class="form-label">ID</label>
              <input type="text" class="form-control" id="id" name="id" readonly>
            </div>
            <div class="mb-3">
              <label for="username" class="form-label">Username</label>
              <input type="text" class="form-control" id="username" name="username">
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input type="password" class="form-control" id="password" name="password">
            </div>
            <div class="mb-3">
              <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
              <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Update</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <!-- plugins:js -->
  <script src="assets/vendors/js/vendor.bundle.base.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.0.1/chart.umd.min.js"></script>




  <!-- inject:js -->
  <script src="assets/js/off-canvas.js"></script>
  <script src="assets/js/misc.js"></script>
  <script src="assets/js/settings.js"></script>
  <script src="assets/js/todolist.js"></script>
  <script src="assets/js/jquery.cookie.js"></script>
  <!-- <script src="assets/js/dashboard.js"></script> -->
  <!-- External Scripts -->

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script> -->
  <script src="https://cdn.datatables.net/2.1.4/js/dataTables.js"></script>
  <script src="https://cdn.datatables.net/2.1.4/js/dataTables.bootstrap5.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    if ($("#visit-sale-chart").length) {
      const ctx = document.getElementById('visit-sale-chart').getContext('2d');

      var graphGradient1 = ctx.createLinearGradient(0, 0, 0, 181);
      graphGradient1.addColorStop(0, 'rgba(218, 140, 255, 1)');
      graphGradient1.addColorStop(1, 'rgba(154, 85, 255, 1)');

      var graphGradient2 = ctx.createLinearGradient(0, 0, 0, 360);
      graphGradient2.addColorStop(0, 'rgba(54, 215, 232, 1)');
      graphGradient2.addColorStop(1, 'rgba(177, 148, 250, 1)');

      var graphGradient3 = ctx.createLinearGradient(0, 0, 0, 300);
      graphGradient3.addColorStop(0, 'rgba(255, 191, 150, 1)');
      graphGradient3.addColorStop(1, 'rgba(254, 112, 150, 1)');

      const dataPendapatan = <?php echo json_encode($data_pendapatan); ?>;

      new Chart(ctx, {
        type: 'bar',
        data: {
          labels: ['JAN', 'FEB', 'MAR', 'APR', 'MEI', 'JUN', 'JUL', 'AGT', 'SEP', 'OKT', 'NOV', 'DES'],
          datasets: [{
            label: "Total Pendapatan",
            borderColor: graphGradient1,
            backgroundColor: graphGradient1,
            fill: true,
            borderWidth: 1,
            data: dataPendapatan,
            barPercentage: 0.5,
            categoryPercentage: 0.5,
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: true,
          scales: {
            y: {
              beginAtZero: true,
              grid: {
                display: true,
              },
              ticks: {
                callback: function(value) {
                  return 'Rp ' + new Intl.NumberFormat().format(value);
                }
              }
            },
            x: {
              grid: {
                display: false,
              },
            }
          },
          plugins: {
            legend: {
              display: true,
            },
          }
        },
      });
    }
  </script>
  <script>
    if ($("#traffic-chart").length) {
      const ctx = document.getElementById('traffic-chart').getContext('2d');

      var graphGradient1 = ctx.createLinearGradient(0, 0, 0, 181);
      graphGradient1.addColorStop(0, 'rgba(54, 215, 232, 1)');
      graphGradient1.addColorStop(1, 'rgba(177, 148, 250, 1)');

      var graphGradient2 = ctx.createLinearGradient(0, 0, 0, 50);
      graphGradient2.addColorStop(0, 'rgba(255, 191, 150, 1)');
      graphGradient2.addColorStop(1, 'rgba(254, 112, 150, 1)');

      var graphGradient3 = ctx.createLinearGradient(0, 0, 0, 300);
      graphGradient3.addColorStop(0, 'rgba(6, 185, 157, 1)');
      graphGradient3.addColorStop(1, 'rgba(132, 217, 210, 1)');

      const kategori = <?php echo json_encode($kategori); ?>;
      const totalPenjualan = <?php echo json_encode($total_penjualan); ?>;

      new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: kategori,
          datasets: [{
            data: totalPenjualan,
            backgroundColor: [graphGradient1, graphGradient2, graphGradient3],
            hoverBackgroundColor: [
              graphGradient1,
              graphGradient2,
              graphGradient3
            ],
            borderColor: [
              graphGradient1,
              graphGradient2,
              graphGradient3
            ]
          }]
        },
        options: {
          cutout: '50%',
          animation: {
            animateRotate: true,
            animateScale: false,
          },
          responsive: true,
          maintainAspectRatio: true,
          plugins: {
            legend: {
              display: false,
            }
          }
        },
        plugins: [{
          afterDatasetUpdate: function(chart, args, options) {
            const chartId = chart.canvas.id;
            const legendId = `${chartId}-legend`;
            const legendElement = document.getElementById(legendId);
            if (legendElement) {
              const ul = document.createElement('ul');
              for (let i = 0; i < chart.data.datasets[0].data.length; i++) {
                ul.innerHTML += `
              <li>
                <span style="background-color: ${chart.data.datasets[0].backgroundColor[i]}"></span>
                ${chart.data.labels[i]}
              </li>
            `;
              }
              legendElement.appendChild(ul);
            } else {
              console.error(`Legend element with id ${legendId} not found.`);
            }
          }
        }]
      });
    }
  </script>
  <script>
    $(document).on('click', '.mdi-cached', function() {
      var userId = $(this).data('id'); // Dapatkan ID pengguna dari atribut data-id
      $.ajax({
        url: 'pages/admin/controller/get-user-data.php', // Endpoint PHP untuk mengambil data pengguna berdasarkan ID
        type: 'GET',
        data: {
          id: userId
        },
        success: function(data) {
          var user = JSON.parse(data);
          $('#id').val(user.id);
          $('#username').val(user.username);
          $('#password').val(''); // Kosongkan password, biarkan pengguna mengisinya
          $('#nama_lengkap').val(user.nama_lengkap);
        }
      });
    });
  </script>
</body>

</html>