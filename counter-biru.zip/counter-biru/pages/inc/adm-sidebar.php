<?php
$page = isset($_GET['page']) ? $_GET['page'] : '';
?>

<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item nav-profile">
            <img src="assets/images/logo-biru.jpg" alt="profile" width="190" />

        </li>
        <li class="nav-item mt-3 <?php echo $page == 'dashboard' ? 'active' : ''; ?>">
            <a class="nav-link" href="?page=dashboard">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
            </a>
        </li>
        <li class="nav-item <?php echo in_array($page, ['kategori-produk', 'stok-produk']) ? 'active' : ''; ?>">
            <a class="nav-link" data-bs-toggle="collapse" href="#manajemen-barang" aria-expanded="<?php echo in_array($page, ['kategori-produk', 'stok-produk']) ? 'true' : 'false'; ?>" aria-controls="manajemen-barang">
                <span class="menu-title">Manajemen Barang</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-package-variant-closed menu-icon"></i>
            </a>
            <div class="collapse <?php echo in_array($page, ['kategori-produk', 'stok-produk']) ? 'show' : ''; ?>" id="manajemen-barang">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $page == 'kategori-produk' ? 'active' : ''; ?>" href="?page=kategori-produk">Kategori</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $page == 'stok-produk' ? 'active' : ''; ?>" href="?page=stok-produk">Barang</a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item <?php echo in_array($page, ['pesanan-masuk', 'riwayat-pesanan']) ? 'active' : ''; ?>">
            <a class="nav-link" data-bs-toggle="collapse" href="#manajemen-pesanan" aria-expanded="<?php echo in_array($page, ['pesanan-masuk', 'riwayat-pesanan']) ? 'true' : 'false'; ?>" aria-controls="manajemen-pesanan">
                <span class="menu-title">Manajemen Pesanan</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-cart menu-icon"></i>
            </a>
            <div class="collapse <?php echo in_array($page, ['pesanan-masuk', 'riwayat-pesanan']) ? 'show' : ''; ?>" id="manajemen-pesanan">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $page == 'pesanan-masuk' ? 'active' : ''; ?>" href="?page=pesanan-masuk">Pesanan Masuk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $page == 'riwayat-pesanan' ? 'active' : ''; ?>" href="?page=riwayat-pesanan">Riwayat Pesanan</a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item <?php echo $page == 'data-pelanggan' ? 'active' : ''; ?>">
            <a class="nav-link" href="?page=data-pelanggan">
                <span class="menu-title">Pelanggan</span>
                <i class="mdi mdi-account-multiple menu-icon"></i>
            </a>
        </li>
        <li class="nav-item <?php echo $page == 'data-pengguna' ? 'active' : ''; ?>">
            <a class="nav-link" href="?page=data-pengguna">
                <span class="menu-title">Data Pengguna</span>
                <i class="mdi mdi-account menu-icon"></i>
            </a>
        </li>
        <li class="nav-item <?php echo in_array($page, ['laporan-pendapatan', 'laporan-pesanan']) ? 'active' : ''; ?>">
            <a class="nav-link" data-bs-toggle="collapse" href="#laporan" aria-expanded="<?php echo in_array($page, ['laporan-pendapatan', 'laporan-pesanan']) ? 'true' : 'false'; ?>" aria-controls="laporan">
                <span class="menu-title">Laporan</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-chart-bar menu-icon"></i>
            </a>
            <div class="collapse <?php echo in_array($page, ['laporan-pendapatan', 'laporan-pesanan']) ? 'show' : ''; ?>" id="laporan">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $page == 'laporan-pendapatan' ? 'active' : ''; ?>" href="?page=laporan-pendapatan">Laporan Pendapatan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $page == 'laporan-pesanan' ? 'active' : ''; ?>" href="?page=laporan-pesanan">Laporan Pesanan</a>
                    </li>
                </ul>
            </div>
        </li>

    </ul>
</nav>