<?php include('config/connection.php') ?>
<div class="container-scroller">
    <?php include('pages/inc/navbar.php') ?>
    <div class="container-fluid page-body-wrapper">
        <?php include('pages/inc/adm-sidebar.php') ?>
        <?php include 'config/routes_admin.php' ?>
    </div>
</div>