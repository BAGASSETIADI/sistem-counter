<?php
// Ambil data user berdasarkan ID
if (isset($_SESSION['id'])) {
    $user_id = $_SESSION['id'];
    $query = "SELECT * FROM pengguna WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Pengguna tidak ditemukan!'
                }).then(function() {
                    window.location = '?page=data-user';
                });
              </script>";
        exit();
    }
} else {
    echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'ID pengguna tidak ditemukan!'
            }).then(function() {
                window.location = '?page=data-user';
            });
          </script>";
    exit();
}

// Proses update data pengguna
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = !empty($_POST['password']) ? $_POST['password'] : $user['password']; // Jika password kosong, gunakan password lama
    $nama_lengkap = $_POST['nama_lengkap'];


    $update_query = "UPDATE pengguna SET username = ?, password = ?, nama_lengkap = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param('sssi', $username, $password, $nama_lengkap, $user_id);

    if ($update_stmt->execute()) {
        $_SESSION['nama'] = $nama_lengkap; // update session name jika nama diubah
        echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil',
                    text: 'Data pengguna berhasil diupdate!'
                }).then(function() {
                    window.location = '?page=data-user';
                });
              </script>";
    } else {
        echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Gagal mengupdate data pengguna!'
                });
              </script>";
    }
}

// Tutup statement dan koneksi
$stmt->close();
if (isset($update_stmt)) {
    $update_stmt->close();
}
$conn->close();
?>

<div class="container">
    <h2 class="mb-4">Pengaturan Akun</h2>
    <form method="POST" action="?page=data-user">
        <input type="hidden" class="form-control" id="id" name="id" value="<?php echo htmlspecialchars($user['id']); ?>" readonly>

        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>">
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" value="">
            <span>Biarkan kosong jika tidak mengubah sandi baru</span>
        </div>
        <div class="mb-3">
            <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
            <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" value="<?php echo htmlspecialchars($user['nama_lengkap']); ?>">
        </div>
        <div class="d-grid">
            <button type="submit" class="btn btn-primary">Update</button>
        </div>
    </form>
    <div class="mt-3">
        <a href="?page=dashboard" class="btn btn-secondary">Kembali ke Dashboard</a>
    </div>
</div>